package model;

public interface ModelServer {
		
	void stopServer();
	void startServer();
}
