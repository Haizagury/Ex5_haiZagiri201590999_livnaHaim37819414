package view;

public interface View {
	void start();
	void exit();

}
